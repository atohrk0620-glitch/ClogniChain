"""
⚠️ NOTICE:
This is a core-reduced version for public sharing.
For full modules including enhanced logic and learning engines,
please reach out for access and collaboration.

Support this project → https://www.paypal.com/paypalme/my/profile
"""

__version__ = "0.1.0"
