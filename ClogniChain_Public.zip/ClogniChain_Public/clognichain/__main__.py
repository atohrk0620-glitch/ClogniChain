from .core import LogicCore

if __name__ == "__main__":
    print("ClogniChain Public Mode")
    core = LogicCore()
    core.run()
